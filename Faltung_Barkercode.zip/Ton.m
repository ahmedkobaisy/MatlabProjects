function sinus_signal = Ton(Ton,x)

    fz = linspace(-1, 1,8192); 

    sinus_signal = sin(2 * pi * Ton * fz);
    % soundsc(sinus_signal);    
end