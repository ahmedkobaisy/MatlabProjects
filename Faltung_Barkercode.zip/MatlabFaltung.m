clc, clearvars, close all

figure(1)
t = 0:14;

x = [0 0 1 2 2 2 0 0];
h = [0 0 2 2 2 2 0 0];

y = conv(x,h);
plot(t,y,'-o');
xlabel('t'),ylabel('y(t)')
grid on

figure(2)
t = 0:6;

x = [1 2 2 2];
h = [2 2 2 2];

y = conv(x,h);
plot(t,y,'-o');
xlabel('t'),ylabel('y(t)')
grid on