function [y] = huellkurve(a,d,s,ed,es,x)
 % a : Relative Laenge Attack Phase
 % d : Relative Laenge Delay Phase, d - a
 % s : Relative Laenge Sustain Phase, s - d
 % ed : Relative Amplitude des Profils zum Zeitpunkt d
 % es : Relative Amplitude des Profils zum Zeitpunkt s
 % x : Eingangston
 % y : Veraenderter Ausgangston

fs = length(x);

A = linspace(0,1,fs*a);
D = linspace(1,ed,fs*d);
S = linspace(ed,es,fs*s);
R = linspace(es,0,fs - (fs*(a+d+s))+1);

hkurve = [A, D, S, R];

y = x .* hkurve;
soundsc(y);


end