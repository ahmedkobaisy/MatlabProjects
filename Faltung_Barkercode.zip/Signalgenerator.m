clear all

for n=0:1000

mode = 'speichereffizient'
switch mode
    case 'speichereffizient'
        tic
        s_n = signal_speichereffizient(n);
        t1 = toc;
        display(t1)
    case 'cpueffizient'
        tic
        s_n = signal_cpueffizient(n);
        t2 = toc;
        display(t2)
        
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hier fehlt Ihr Code zur %
% Anzeige des Signals %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hold on
plot(n,s_n,'.k')
xlim([n-50 n+50])
drawnow
hold off


end



