function [s_n] = signal_speichereffizient(n)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
mode = mod(n,60);

if(mode == 0)
    s_n = 0;
elseif mode < 10
    s_n = mod(n,10) * 40;
elseif (mode >= 10 & mode < 20)
    s_n = 400;
elseif (mode >= 20 & mode < 30)
    s_n = 400 - mod(n,10) * 40;
elseif (mode >= 30 & mode < 40)
    s_n = - mod(n,10) * 40;
elseif (mode >= 40 & mode < 50)
    s_n = -400;
elseif (mode >= 50 & mode < 60)
    s_n = -400 + mod(n,10) * 40;
end
end