function [s_n] = signal_cpueffizient(n)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

    A = linspace(0,360,10);
    B = ones(1,10) * 400;
    C = linspace(400,-400,21);
    D = ones(1,10) * (-400);
    E = linspace(-360,-40,9);
    
    arr = [A, B, C, D, E];
        %tic
    a = mod(n+1,60);
    if(mod(n+1,60) == 0)
        a = 60;
    end
    s_n = arr(1,a);
        %t(n)= toc;
    end
