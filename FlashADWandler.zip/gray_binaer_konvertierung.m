function binary = gray_binaer_konvertierung(gray)
    binary = gray(1);
    
    for i = 2:length(gray)
        next_bit = xor(str2double(binary(i-1)), str2double(gray(i)));
        binary = strcat(binary, num2str(next_bit)); 
    end
end
