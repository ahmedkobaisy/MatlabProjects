function dezimal = binaer_dezimal_konvertierung(binary)
    dezimal = 0;
    

    for i = 1:length(binary)
        bit = str2double(binary(i));  
        dezimal = dezimal + bit * 2^(length(binary) - i);  
    end
end
