close all
bit = 3;

%D
ux = audioread('fadc.wav');
%soundsc(ux);

%E
y = flashadc(ux,1,1,0,bit);
for k = 1 : length(y)
l = gray_binaer_konvertierung(y{k});
dezimal(k) = binaer_dezimal_konvertierung(l);
end

dezimal = dezimal / (2^bit - 1);

%F
quantisierung = ux.' - dezimal;

subplot(3,1,1)
plot(ux)
title('Originalsignal')
xlabel('Zeit (t)')
ylabel('Amplitude (V)')
subplot(3,1,2)
plot(dezimal)
title('Konvertiertes Signal')
xlabel('Zeit (t)')
ylabel('Amplitude (V)')

subplot(3,1,3)
plot(quantisierung)
title('Quantisierungsfehler')
xlabel('Zeit (t)')
ylabel('Amplitude (V)')
