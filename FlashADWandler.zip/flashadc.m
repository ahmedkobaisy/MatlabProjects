function gray_output = flashadc(ux,ur,ucc, uee,bit)

gray_output = cell(length(ux),1);
for k = 1 : length(ux)
    rgesamt = 2^bit; 
    komp_zahl = 0;                        % einzelne R's -> gleichmäßige Intervalle
    for rk = 1:rgesamt - 1
        spannung = Spannungsteiler(ur,rk,rgesamt);
        y = komparator(ux(k),spannung, ucc, uee);
        komp_zahl = komp_zahl + y;
    end
    
    binary = dezimal_binaer_konvertierung(komp_zahl);
    gray_output{k} = binaer_gray_konvertierung(binary);
end
end
