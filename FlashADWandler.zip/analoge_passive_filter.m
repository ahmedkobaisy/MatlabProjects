% Parameter
R = 1000; % Widerstand in Ohm
C = 0.1e-6; % Kapazität in Farad
Vin = 5; % Eingangsspannung in Volt

% Frequenzbereich
f = logspace(0, 8, 1000); % Frequenzbereich von 1 Hz bis 100 MHz

% Berechnung der Übertragungsfunktion des Tiefpass RC-Filters
H = 1 ./ (1 + 1i * 2 * pi * f * R * C);

% Berechnung der Ausgangsspannung
Vout = Vin * H;

% Grundfrequenzen
f0 = [1e3, 1.5e3, 5e3, 10e3, 100e3]; % Frequenzen in Hz

% Zeitvektor
fs = 10 * max(f0); % Abtastrate wählen
t = 0:1/fs:0.01; % Zeitvektor von 0 bis 0.01 Sekunden

% Originalsignale erzeugen
S = cell(1, length(f0));
for i = 1:length(f0)
    S{i} = Vin * sin(2*pi*f0(i)*t);
end

% Tiefpass RC-Filter
H = 1 ./ (1 + 1i * 2 * pi * f0 * R * C);

% Gefilterte Signale
S_filtered = cell(1, length(f0));
for i = 1:length(f0)
    S_filtered{i} = Vin * H(i) * sin(2*pi*f0(i)*t);
end

% Plots
figure;
for i = 1:length(f0)
    subplot(length(f0), 1, i);
    plot(t, S{i}, 'b', t, S_filtered{i}, 'r', 'LineWidth', 2);
    xlabel('Zeit (s)');
    ylabel('Amplitude (V)');
    title(['Grundfrequenz: ', num2str(f0(i)/1000), ' kHz']);
    legend('Original', 'Gefiltert');
    grid on;
end


% Berechnung der Cut-off-Frequenz
fc = 1 / (2 * pi * R * C);

% Ergebnis ausgeben
fprintf('Die Cut-off-Frequenz fc beträgt %.2f Hz\n', fc);

% Plot der Frequenzantwort
loglog(f, abs(Vout), 'LineWidth', 2);
xlabel('Frequency (Hz)');
ylabel('Magnitude');
title('Frequency Response of RC Low-pass Filter');
grid on;

% Parameter
R = 1000; % Widerstand in Ohm
C = 0.1e-6; % Kapazität in Farad

% Frequenzbereich
f = logspace(0, 8, 1000); % Frequenzbereich von 1 Hz bis 100 MHz

% Übertragungsfunktion des Tiefpass RC-Filters
H = 1 ./ (1 + 1i * 2 * pi * f * R * C);

% Bode-Diagramm
figure;
subplot(2,1,1);
semilogx(f, 20*log10(abs(H)), 'LineWidth', 2);
hold on;
plot([1, 1]*1/(2*pi*R*C), ylim, 'r--', 'LineWidth', 1.5); % Cut-off Frequenz
hold off;
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)');
title('Bode Diagramm des Tiefpass RC-Filters');
grid on;

% Bereiche kennzeichnen
text(10, -3, 'Stopband', 'FontSize', 12);
text(1e6, -3, 'Passband', 'FontSize', 12);
ylim([-40, 10]);
xlim([1, 1e7]);

% Phase
subplot(2,1,2);
semilogx(f, angle(H) * 180/pi, 'LineWidth', 2);
xlabel('Frequency (Hz)');
ylabel('Phase (degrees)');
grid on;