function y = komparator(pos,neg,ucc,uee)
if(pos > neg)
    y = ucc;
else
    y = uee;
end