function y = Spannungsteiler(ur,rk,rges)
y = ur*(rk / rges);
end