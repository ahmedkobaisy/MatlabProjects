   close all, clearvars
    
   subplot(4,1,1);
   
   %Time specifications:
   Fs = 8192;                           % samples per second
   dt = 1/Fs;                           % seconds per sample
   StopTime = 0.02;                     % seconds
   t = (0:dt:StopTime);                 % array

   %S1:
   VPP = 2;                             % voltage Peak to Peak
   Fc = 500;                            % hertz
   amplitude = VPP / 2;                 % amplitude  
   S1 = amplitude*sin(2*pi*Fc*t);

   % Plot S1:
   plot(t,S1);
   ylim([-1 1]);
   title('Subplot 1: S1');
   ylabel('S1(t) [V]')

  
   subplot(4,1,2);

   %S2:
   VPP = 1;                             % voltage Peak to Peak
   Fc = 1000;                           % hertz
   amplitude = VPP / 2;                 % amplitude  
   S2 = amplitude*sin(2*pi*Fc*t);

   plot(t,S2);
   ylim([-1 1])
   title('Subplot 2: S2');
   ylabel('S2(t) [V]')


   subplot(4,1,3);

   %S3:
   VPP = 0.4;                           % voltage Peak to Peak
   Fc = 1500;                           % hertz
   amplitude = VPP / 2;                 % amplitude  
   S3 = amplitude*sin(2*pi*Fc*t);

   % Plot S3:
   plot(t,S3);
   ylim([-1 1])
   title('Subplot 3: S3');
   ylabel('S3(t) [V]')

   subplot(4,1,4);

   S4 = S1 + S2 + S3;

   plot(t, S4);
   ylim([-2 2]);
   title('Subplot 4: S4');
   xlabel('time (in seconds)');
   ylabel('S4(t) [V]')

