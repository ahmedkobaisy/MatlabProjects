   close all   

   %Time specifications:
   Fs = 8192;                           % samples per second
   dt = 1/Fs;                           % seconds per sample
   StopTime = 0.02;                     % seconds
   t = (0:dt:StopTime);                 % array

   %S1:
   VPP = 2;                             % voltage Peak to Peak
   Fc = 500;                            % hertz
   amplitude = VPP / 2;                 % amplitude  
   S1 = amplitude*sin(2*pi*Fc*t);

   %S2:
   VPP = 1;                             % voltage Peak to Peak
   Fc = 1000;                           % hertz
   amplitude = VPP / 2;                 % amplitude  
   S2 = amplitude*sin(2*pi*Fc*t);

   %S3:
   VPP = 0.4;                           % voltage Peak to Peak
   Fc = 1500;                           % hertz
   amplitude = VPP / 2;                 % amplitude  
   S3 = amplitude*sin(2*pi*Fc*t);

   S4 = S1 + S2 + S3;
   ueff_S4 = max(S4) / sqrt(2);         % caltulate effective value of S4

   %A
   figure(1);
   noise = randn(1,Fs+1);
   histogram(noise,1000);
   xlabel('Bin Number')
   ylabel('Relative Frequency of Numbers')
   

   %B
   figure(2);
   y = xcorr(noise);
   plot(y)
   xlabel('Bin Number')
   ylabel('Relative Frequency of Numbers')


   %C
   figure(3);
   a = 3.5;
   b = 5;
   noise2 = a + sqrt(b^2)*randn(1,Fs+1);
   histogram(noise2,1000)
   xlabel('Bin Number')
   ylabel('Relative Frequency of Numbers')

   %Variables
   ueff_5 = 0.01;
   amp_5 = (ueff_5 * sqrt(2));
   ueff_6 = 0.1;
   amp_6 = (ueff_6 * sqrt(2));
   ueff_7 = 5;
   amp_7 = (ueff_7 * sqrt(2));

   %D
   noise5 = (amp_5 / 4).* randn(1,Fs) - 0.0002;
   noise5_range = [min(noise5) max(noise5)]

   noise6 = (amp_6 / 3.5).* randn(Fs,1) - 0.005;
   noise6_range = [min(noise6) max(noise6)]

   noise7 = (amp_7 / 4.3).* randn(Fs,1) - 0.02;
   noise7_range = [min(noise7) max(noise7)]

   %E
   SNR_5 = 10*log(ueff_S4^2/ueff_5^2);
   SNR_6 = 10*log(ueff_S4^2/ueff_6^2);
   SNR_7 = 10*log(ueff_S4^2/ueff_7^2);

   %F
   soundsc(noise5);
   pause(2);
   soundsc(noise6);
   pause(2);
   soundsc(noise7);
   pause(2);



