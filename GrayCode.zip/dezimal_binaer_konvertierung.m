function binary = dezimal_binaer_konvertierung(dezimal)
    binary = '';
    
    if dezimal == 0
        binary = '0';
        return;
    end
    
    while dezimal > 0
        rest = mod(dezimal, 2);  
        binary = strcat(num2str(rest), binary);  
        dezimal = floor(dezimal / 2);  
    end
end
