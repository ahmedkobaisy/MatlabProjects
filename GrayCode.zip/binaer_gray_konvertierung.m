function gray = binaer_gray_konvertierung(binary)
    gray = binary(1);
    
    for i = 2:length(binary)
        next_bit = xor(str2double(binary(i-1)), str2double(binary(i)));
        gray = strcat(gray, num2str(next_bit));
    end
end
