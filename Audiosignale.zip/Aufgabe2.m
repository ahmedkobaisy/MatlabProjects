%Töne 

fzHohesA = 880;
fzA = 440; 
fzB = 446,164;
fzH = 493,88;
fzC = 523,25;
fzCis = 554,365;
fzD = 587,32;
fzDis = 622,25;
fzE = 659,255;
fzF = 698,456;
fzFis = 739,988;
fzG = 783,99;
fzGis = 830,6;


%Takt1

Ton(fzC,1);
Ton(fzD,1);
Ton(fzE,1);
Ton(fzF,1);

%Takt 2

Ton(fzG,2);
Ton(fzG,2);

%Takt 3

Ton(fzHohesA,1);
Ton(fzHohesA,1);
Ton(fzHohesA,1);
Ton(fzHohesA,1);

%Takt 4

Ton(fzG,2);

%Takt 5

Ton(fzHohesA,1);
Ton(fzHohesA,1);
Ton(fzHohesA,1);
Ton(fzHohesA,1);

%Takt 6

Ton(fzG,2);

%Takt 7

Ton(fzF,1);
Ton(fzF,1);
Ton(fzF,1);
Ton(fzF,1);

%Takt 8

Ton(fzE,2);
Ton(fzE,2);

%Takt 9

Ton(fzD,1);
Ton(fzD,1);
Ton(fzD,1);
Ton(fzD,1);

%Takt 10

Ton(fzC,2);