clc, clearvars, close all
%Aufgabe 11.1

t = (0: .001:1)';  %Zeit in [S]
x0 = 1;           %Amplitude
f0 = 4;           %Grundfrequenz in [Hz]
x_t = x0*sin(2*pi*f0*t);
figure(1)
plot(t, x_t)
hold on 
grid on
xlabel('x'),ylabel('t')

n = 1:64;         %Diskrete Zeitschritte
fs= 64;           %Abtastfrequenz in [Hz]
Ts= 1/fs;         %Abtastintervall in [s]
x_n= x0*sin(2*pi*f0*n*Ts);
stem(n*Ts,x_n)
xlabel('x'),ylabel('n')
grid on
