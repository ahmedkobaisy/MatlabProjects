close all

Fs = 8192;                           
t = 0:1/Fs:1;
M = 40;
Fc = 800;

wc = 2*pi*Fc/Fs;
hm = zeros(M + 1,1);
wm = zeros(M+1,1);

%S1:
S1 = 1*sin(2*pi*500*t);

%S2:
S2 = 0.5*sin(2*pi*1000*t);

%S3:                    
S3 = 0.2*sin(2*pi*1500*t);

%S4
S4 = S1 + S2 + S3;

%S7
ueff_7 = 5;
amp_7 = (ueff_7 * sqrt(2));
random = randn(1,Fs+1);
noise7 = (amp_7 / max(abs(random), [], 'all')) * random;
S7 = S4 + noise7;

%A
for m = 0:M
    hm(m+1) = wc/pi * sinc(wc*(2*m - M)/ 2* pi);
    wm(m+1) = 0.54 - 0.46 * cos(2*pi*m/M);
end

firFilter = hm .* wm;
S8 = conv(S7,firFilter);
S8 = S8(1:length(t));

figure(1);
subplot(2,1,1);
plot(t,S7);
title('Original Noisy Signal S7');
subplot(2,1,2);
plot(t(1:length(S8)),S8);
title('Filtered Signal S8');


soundsc(S4, Fs);
pause(2);
soundsc(S8, Fs);

%B
% Filter um 500 Hz
wp_500 = 450;
ws_500 = 550;
firFilter_500 = BandpassFilter(M, Fs, wp_500, ws_500);

% Filter um 1000 Hz
wp_1000 = 950;
ws_1000 = 1050;
firFilter_1000 = BandpassFilter(M, Fs, wp_1000, ws_1000);

% Filter um 1500 Hz
wp_1500 = 1450;
ws_1500 = 1550;
firFilter_1500 = BandpassFilter(M, Fs, wp_1500, ws_1500);

%C
summe_bfilter = firFilter_500 + firFilter_1000 + firFilter_1500;
S9 = conv(summe_bfilter, S7);

%D
% Filter um 500 Hz
M = 400;
wp_500 = 495;
ws_500 = 505;
firFilter_500 = BandpassFilter(M, Fs, wp_500, ws_500);
firFilterNorm_500 = firFilter_500 / max(abs(firFilter_500), [], 'all');

% Filter um 1000 Hz
wp_1000 = 995;
ws_1000 = 1005;
firFilter_1000 = BandpassFilter(M, Fs, wp_1000, ws_1000);
firFilterNorm_1000 = firFilter_1000 / max(abs(firFilter_1000), [], 'all');

% Filter um 1500 Hz
wp_1500 = 1495;
ws_1500 = 1505;
firFilter_1500 = BandpassFilter(M, Fs, wp_1500, ws_1500);
firFilterNorm_1500 = firFilter_1500 / max(abs(firFilter_1500), [], 'all');

summe_bfilter_norm = firFilterNorm_500 + firFilterNorm_1000 + firFilterNorm_1500;
S10 = conv(summe_bfilter_norm, S7);

%E
figure(2);
subplot(4,1,1);
plot(t,S7);
title('Original Noisy Signal S7');
subplot(4,1,2);
plot(t(1:length(S8)),S8);
title('Filtered Signal S8');

middle = floor(length(S9)/2);
halfLengthOfS7 = floor(length(S7)/2);
S9_cropped = S9(middle - halfLengthOfS7 + 1 : middle + halfLengthOfS7);

middle = floor(length(S10)/2);
halfLengthOfS7 = floor(length(S7)/2);
S10_cropped = S10(middle - halfLengthOfS7 + 1 : middle + halfLengthOfS7);


subplot(4,1,3);
plot(t(1:length(S9_cropped)),S9_cropped);
title('Filtered Signal S9');
subplot(4,1,4);
plot(t(1:length(S10_cropped)),S10_cropped);
title('Filtered Signal S10');


soundsc(S7, Fs);
pause(2);
soundsc(S8, Fs);
pause(2);
soundsc(S9, Fs);
pause(2);
soundsc(S10, Fs);



