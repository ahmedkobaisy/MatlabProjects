close all

Fs = 8192;                           
t = 0:1/Fs:1;
M = 40;
Fc = 800;

wc = 2*pi*Fc/Fs;
hm = zeros(M + 1,1)
wm = zeros(M+1,1);

%S1:
S1 = 1*sin(2*pi*500*t);

%S2:
S2 = 0.5*sin(2*pi*1000*t);

%S3:                    
S3 = 0.2*sin(2*pi*1500*t);

%S4
S4 = S1 + S2 + S3;

%S7
ueff_7 = 5;
amp_7 = (ueff_7 * sqrt(2));
random = randn(1,Fs+1);
noise7 = (amp_7 / max(abs(random), [], 'all')) * random;
S7 = S4 + noise7;

%A
for m = 0:M
    hm(m+1) = wc/pi * sinc(wc*(2*m - M)/ 2* pi);
    wm(m+1) = 0.54 - 0.46 * cos(2*pi*m/M);
end

%B
firFilter = hm .* wm;

%c
faltS7 = conv(S7,firFilter);

%d
dftS7 = fft(S7);
dftFilS7 = fft(faltS7);

N = length(dftS7);
dftS7 = abs(dftS7(1:N/2));
dftFilS7 = abs(dftFilS7(1:N/2));

f = (0:N/2-1)*Fs/N;

subplot(2,1,1)
plot(f, dftS7);
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)');
title('DFT of Original Signal');
ylim([0 N/2 - 1]);
xlim([0 N/2 - 1]);

subplot(2,1,2)
plot(f, dftFilS7);
ylim([0 N/2 - 1]);
xlim([0 N/2 - 1]);
xlabel('Frequency (Hz)');
ylabel('Magnitude (dB)');
title('DFT of Filtered Signal');

