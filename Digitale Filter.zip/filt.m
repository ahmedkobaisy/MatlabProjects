function [y, px, py] = filt(b, a, x, px, py)
    % Anzahl der Koeffizienten
    N = length(b) - 1;
    M = length(a) - 1;
    
    % Initialisiere den Output
    y = zeros(1, length(x));
    
    % Filterausführung
    for k = 1:length(x)
        % Berechne den neuen Wert für y[k]
        y(k) = b(1) * x(k);
        for n = 1:N
            if k > n
                y(k) = y(k) + b(n+1) * x(k-n);
            end
        end
        for n = 1:M
            if k > n
                y(k) = y(k) - a(n+1) * y(k-n);
            end
        end
        % Aktualisiere px und py
        if k <= N
            px(k) = x(k);
        end
        if k <= M
            py(k) = y(k);
        end
    end
end
