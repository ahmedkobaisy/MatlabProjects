% https://de.mathworks.com/videos/understanding-the-z-transform-1680761476178.html


%A
%Time specifications:
tic()
Fs = 8192;                           
t = 0:1/Fs:1;                       
T = 1/Fs; 
N = 8192; 

%S1:
S1 = 1*sin(2*pi*500*t);

%S2:
S2 = 0.5*sin(2*pi*1000*t);

%S3:                    
S3 = 0.2*sin(2*pi*1500*t);


%% Berechnen Sie hier das Signal S4
S4 = S1 + S2 + S3;

%A
DFT_S4 = DFT(S4);
z_P = 1/N * abs(DFT_S4);
einseitiges_spektrum_S4 = z_P(1:N/2+1);
einseitiges_spektrum_S4(2:end-1) = 2*einseitiges_spektrum_S4(2:end-1);

%% Ergebnisse Plotten
figure(1);
stem(0:N/2,einseitiges_spektrum_S4)
xlim([0 N/2]);
title('Einseitiges Spektrum von S4(t)')
xlabel('f (Hz)')
ylabel('|P(f)|')
toc()

%B
tic()
fft_S4 = fft(S4);
P2 = abs(fft_S4/N);
P1 = P2(1:N/2+1);
P1(2:end-1) = 2*P1(2:end-1);

figure(2);
plot(P1,"LineWidth",3)
title("Single-Sided Amplitude Spectrum of S(t)")
xlim([0 length(P1)])
xlabel("f (Hz)")
ylabel("|P1(f)|")
toc()


%D
%Variablen
ueff_5 = 0.01;
amp_5 = (ueff_5 * sqrt(2));
ueff_6 = 0.1;
amp_6 = (ueff_6 * sqrt(2));
ueff_7 = 5;
amp_7 = (ueff_7 * sqrt(2));

%S5
figure(3);
subplot(3,2,1);
random = randn(1,Fs+1);
noise5 = (amp_6 / max(abs(random), [], 'all')) * random;
S5 = S4 + noise5;
plot(S5)
title("S5")
xlabel('f (Hz)')
ylabel('X(t)')

%DFT S5
DFT_S5 = DFT(S5);
z_P = 1/N * abs(DFT_S5);
einseitiges_spektrum_S5 = z_P(1:N/2+1);
einseitiges_spektrum_S5(2:end-1) = 2*einseitiges_spektrum_S5(2:end-1);

%S6
subplot(3,2,3);
random = randn(1,Fs+1);
noise6 = (amp_6 / max(abs(random), [], 'all')) * random;
S6 = S4 + noise6;
plot(S6)
title("S6")
xlabel('f (Hz)')
ylabel('X(t)')

%DFT S6
DFT_S6 = DFT(S6);
z_P = 1/N * abs(DFT_S6);
einseitiges_spektrum_S6 = z_P(1:N/2+1);
einseitiges_spektrum_S6(2:end-1) = 2*einseitiges_spektrum_S6(2:end-1);

%S7
subplot(3,2,5);
random = randn(1,Fs+1);
noise7 = (amp_7 / max(abs(random), [], 'all')) * random;
S7 = S4 + noise7;
plot(S7)
title("S7")
xlabel('f (Hz)')
ylabel('X(t)')


%DFT S7
DFT_S7 = DFT(S7);
z_P = 1/N * abs(DFT_S7);
einseitiges_spektrum_S7 = z_P(1:N/2+1);
einseitiges_spektrum_S7(2:end-1) = 2*einseitiges_spektrum_S7(2:end-1);

%E
%Inverse S5 Berechnen
iS5 = iDFT(DFT_S5);

subplot(3,2,2);
plot(iS5,"LineWidth",3)
title("iDFT S5")
xlabel("f (Hz)")
ylabel("X(t)")

%Inverse S6 Berechnen
iS6 = iDFT(DFT_S6);

subplot(3,2,4);
plot(iS6,"LineWidth",3)
title("iDFT S6")
xlabel("f (Hz)")
ylabel("X(t)")

iS7 = iDFT(DFT_S7);

subplot(3,2,6);
plot(iS7,"LineWidth",3)
title("iDFT S7")
xlabel("f (Hz)")
ylabel("X(t)")

