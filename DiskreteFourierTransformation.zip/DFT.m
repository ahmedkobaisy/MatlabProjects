function fourier_signal = DFT(Signal)
    Fs = 8192;                           % Abtastfrequenz
    N = 8192;                            % Signallaenge
    
    Xre = zeros(1,N);
    Xim = zeros(1,N);
    x = zeros(1,N);
    y = zeros(1,N);

    %% DFT Berechnen
    for n = 0 : N-1 
        
        for k = 1 : N
    
             %% Realteil von DFT(x(k))
            x(k) = Signal(k) * cos(2*pi*k*n/N);
    
            %% Imaginaerteil von DFT(x(k))
            y(k) = - (Signal(k) * sin(2*pi*k*n/N));
    
        end
    
        Xre(n+1) = sum(x);
    
        Xim(n+1) = sum(y);
     end
    
     %% Zweiseitiges normiertes Spektrum
     fourier_signal = Xre + 1i*Xim;
     
     
end