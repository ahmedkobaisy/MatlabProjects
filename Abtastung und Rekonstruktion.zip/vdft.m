
close all

Fs = 8192;                           
t = 0:1/Fs:1;                       
T = 1/Fs; 
N = 8192; 
f = ([250 500 750 1000]);

%S1:
S1 = 1*sin(2*pi*500*t);

%S2:
S2 = 0.5*sin(2*pi*1000*t);

%S3:                    
S3 = 0.2*sin(2*pi*1500*t);


%% Berechnen Sie hier das Signal S4
S4 = S1 + S2 + S3;

for i = 1:4
    figure(i);
    subplot(2, 1, 1);
    plot(t, S4);
    hold on;
    plot(t, sin(2*pi*f(i)*t)); 
    plot(t, cos(2*pi*f(i)*t));
    hold off;
    xlim([0 0.02])
    ylim([-1.5 1.5])
    title('S4 Signal und Sinus- und Kosinussignal für die zu untersuchende Frequenz');

    fourier_S4 = DFT(S4); 
    re = real(fourier_S4); 
    im = - imag(fourier_S4); 

    freq = (0:N-1)*(Fs/N); 
    
    subplot(2, 1, 2);
    plot(freq(1:N/2), abs(re(1:N/2))); % Plotten Sie den Realteil
    hold on;
    plot(freq(1:N/2), abs(im(1:N/2))); % Plotten Sie den Imaginärteil
    hold off;
    title('Real- und Imaginärteil der DFT');

 
    Sum_Re = sum(re);
    Sum_Im = sum(im);
    
   
    disp(['Summe des Realteils: ', num2str(Sum_Re)])
    disp(['Summe des Imaginärteils: ', num2str(Sum_Im)])

end