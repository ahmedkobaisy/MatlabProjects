function S4_reconstructed = iDFT(DFT)

    Xre = real(DFT);
    Xim = imag(DFT);
    N = 8192;
    S4_reconstructed = zeros(1,N);

    for n = 0:N-1
        for k = 1:N
            S4_reconstructed(n+1) = S4_reconstructed(n+1) + (Xre(k)*cos(2*pi*(n)*(k-1)/N) - Xim(k)*sin(2*pi*(n)*(k-1)/N))/N;
        end
    end
end