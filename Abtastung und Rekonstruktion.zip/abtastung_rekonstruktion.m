close all
N = 8192; 
t_S4 = 0:1/N:1;                                           

fs = [0.5 1 2 3 10] * 1000;

%S1:
S1_t_S4 = 1*sin(2*pi*500*t_S4);

%S2:
S2_t_S4 = 0.5*sin(2*pi*1000*t_S4);

%S3:                    
S3_t_S4 = 0.2*sin(2*pi*1500*t_S4);

S1_S2 = S1_t_S4 + S2_t_S4;

%% Berechnen Sie hier das Signal S4
S4_t_S4 = S1_t_S4 + S2_t_S4 + S3_t_S4;


for i = 1:length(fs)
    t = 0:1/fs(i):1;

    figure(i);
    
    subplot(4,1,1);
    plot(t_S4,S1_t_S4);
    xlim([0 0.02]);
    title('S1');
    
    hold on
    plot(t_S4,S1_S2);
    xlim([0 0.1]);
    title('S1 + S2');
    plot(t_S4,S4_t_S4);
    xlim([0 0.02]);
    ylim([-2 2]);
    title('Ursprüngliches S4 Signal');
    hold off
    
    S1 = 1*sin(2*pi*500*t);
    S2 = 0.5*sin(2*pi*1000*t);                 
    S3 = 0.2*sin(2*pi*1500*t);
    S4 = S1 + S2 + S3;
    
    S4_DFT = fft(S4);
    f = fs(i)/length(S4)*(0:(length(S4)/2));
    P2 = abs(S4_DFT/length(S4));
    P1 = P2(1:length(S4)/2+1);
    P1(2:end-1) = 2*P1(2:end-1);

    S4_reconstructed = interp1(t,S4,t_S4);
    
    
    subplot(4,1,2);
    plot(t, S4);
    xlim([0 0.02]);
    ylim([-2 2]);
    title('Generiertes S4 Signal');
    
    subplot(4,1,3);
    plot(f,P1);
    xlim([0 length(P1)]);
    ylim([0 1.5]);
    title('DFT des generierten Signals')
    
    subplot(4,1,4);
    plot(t_S4,S4_reconstructed);
    xlim([0 0.02]);
    ylim([-2 2]);
    title('Rekonstruktion des S4 Signals');


end

%E

fs = [0.5 1 2 3 10] * 5000;

%S1:
S1_t_S4 = 1*sin(2*pi*500*t_S4);

%S2:
S2_t_S4 = 1.5*sin(2*pi*1000*t_S4);

%S3:                    
S3_t_S4 = 2*sin(2*pi*1500*t_S4);

S1_S2 = S1_t_S4 + S2_t_S4;

for i = 1:length(fs)
    t = 0:1/fs(i):1;

    figure(i+5);
    
    subplot(4,1,1);
    plot(t_S4,S1_t_S4);
    xlim([0 0.02]);
    title('S1');
    
    hold on
    plot(t_S4,S1_S2);
    xlim([0 0.1]);
    title('S1 + S2');
    plot(t_S4,S4_t_S4);
    xlim([0 0.02]);
    ylim([-3 3]);
    title('Ursprüngliches S4 Signal');
    hold off
    
    S1 = 1*sin(2*pi*500*t);
    S2 = 1.5*sin(2*pi*1000*t);                 
    S3 = 2*sin(2*pi*1500*t);
    S4 = S1 + S2 + S3;
    
    S4_DFT = fft(S4);
    f = fs(i)/length(S4)*(0:(length(S4)/2));
    P2 = abs(S4_DFT/length(S4));
    P1 = P2(1:length(S4)/2+1);
    P1(2:end-1) = 2*P1(2:end-1);

    S4_reconstructed = interp1(t,S4,t_S4);
    
    
    subplot(4,1,2);
    plot(t, S4);
    xlim([0 0.02]);
    ylim([-4 4]);
    title('Generiertes S4 Signal');
    
    subplot(4,1,3);
    plot(f,P1);
    xlim([0 length(P1)]);
    ylim([0 2]);
    title('DFT des generierten Signals')
    
    subplot(4,1,4);
    plot(t_S4,S4_reconstructed);
    xlim([0 0.02]);
    ylim([-4 4]);
    title('Rekonstruktion des S4 Signals');


end




